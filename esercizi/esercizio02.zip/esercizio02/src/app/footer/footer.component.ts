import { Component } from "@angular/core";

@Component({
    templateUrl: './footer.component.html',
    selector: 'footer-comp',
    styleUrls: ['./footer.component.css']
})
export class FooterComponent {

}