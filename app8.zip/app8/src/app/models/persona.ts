export class Persona {
    constructor(
        public nome: string,
        public cognome: string
    ) { }
}