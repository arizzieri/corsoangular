import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Persona } from '../models/persona';

@Component({
  selector: 'app-template-variables',
  templateUrl: './template-variables.component.html',
  styleUrls: ['./template-variables.component.css']
})
export class TemplateVariablesComponent implements OnInit {
  numero = 10;
  persone: Persona[];

  @ViewChild('display') display!: ElementRef;

  constructor() {
    this.persone = [
      new Persona("Maria", "Verdi"),
      new Persona("Raffaella", "Bianchi"),
      new Persona("Cinzia", "Marrone")
    ];
  }

  ngOnInit(): void {
  }
  prendiColore(casella: any): void {
    // prendo come parametro la casella di testo
    // con l'identificativo #colore
    alert("Il tuo colore: " + casella.value);
  }
  inserisci(n: any, c: any): void {
    this.persone.push(new Persona(n.value, c.value));
    n.value = '';
    c.value = '';
  }

  elimina(p: number): void {
    if (confirm('Sei sicuro di eliminare ' + this.persone[p].nome + "?")) {
      // aggiorno il display
      this.display.nativeElement.innerHTML += "Eliminato " + this.persone[p].nome + "<br>";
      this.persone.splice(p, 1);
    }






  }
}