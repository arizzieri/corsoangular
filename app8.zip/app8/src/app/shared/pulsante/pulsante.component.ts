import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pulsante',
  templateUrl: './pulsante.component.html',
  styleUrls: ['./pulsante.component.css']
})
export class PulsanteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
