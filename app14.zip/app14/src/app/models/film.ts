export interface Film {
    id: number,
    titolo: string,
    genere: string
}
