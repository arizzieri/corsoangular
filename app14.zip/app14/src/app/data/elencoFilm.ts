import { Film } from "../models/film";

export const elencoFilm: Film[] = [
    {
        id: 1,
        titolo: "Il mondo perduto",
        genere: "Fantasy"
    },
    {
        id: 2,
        titolo: "Il dopoguerra",
        genere: "Storico"
    },
    {
        id: 3,
        titolo: "Il signore degli agnelli",
        genere: "Fantasy"
    },
    {
        id: 4,
        titolo: "Omicidio sul ponte",
        genere: "Thriller"
    },

]