import { Atleta } from "../models/atleta";

export const atleti: Atleta[] = [
    {
        id: 1,
        nome: "Roberto",
        cognome: "Verdi",
        punti: 90
    },
    {
        id: 2,
        nome: "Giovanni",
        cognome: "Rossi",
        punti: 67
    },
    {
        id: 3,
        nome: "Fabio",
        cognome: "Bianchi",
        punti: 88
    },
    {
        id: 4,
        nome: "Diego",
        cognome: "Neri",
        punti: 70
    }
];