export interface Atleta {
    id: number,
    nome: string,
    cognome: string,
    punti: number
}
