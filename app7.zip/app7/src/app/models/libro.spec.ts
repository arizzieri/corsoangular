import { Libro } from './libro';

describe('Libro', () => {
  it('should create an instance', () => {
    expect(new Libro()).toBeTruthy();
  });
});
