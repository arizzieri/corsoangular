export class Libro {
    constructor(public codice: number, public titolo: string, public autore: string, public anno: number) { }
}
