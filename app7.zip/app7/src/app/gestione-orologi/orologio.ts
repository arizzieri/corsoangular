export class Orologio {
    // dichiarazione semplificata degli attributi nel costruttore
    constructor(public ore: number, public minuti: number) { }

    vediOrario(): string {
        // metodo che restituisce un'ora formattata in hh:mm

        // trasformo ore e minuti in stringhe
        let oreStringa: string = this.ore + '';
        let minutiStringa: string = this.minuti + '';

        if (oreStringa.length < 2)
            oreStringa = '0' + oreStringa;
        if (minutiStringa.length < 2)
            minutiStringa = '0' + minutiStringa;

        return "Sono le ore " + oreStringa + ':' + minutiStringa;
    }
}