import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mio-componente',
  templateUrl: './mio-componente.component.html',
  styleUrls: ['./mio-componente.component.css']
})
export class MioComponenteComponent implements OnInit {
  nome?: string = "Federico"; // valore opzionale 
  prezzo: number = 1200;
  numeroPezzi: number = 5;
  cognome: string = "Rossi";

  oggi: Date = new Date(); // data di oggi

  link: string = "http://www.google.it"; // URL percorso web
  immagine: string = "assets/img/ps5.jpg"; // percorso immagine

  constructor() { }

  ngOnInit(): void {
  }

}
