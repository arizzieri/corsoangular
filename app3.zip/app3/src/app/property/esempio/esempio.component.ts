import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-esempio',
  templateUrl: './esempio.component.html',
  styleUrls: ['./esempio.component.css']
})
export class EsempioComponent implements OnInit {
  percorsoImg: string = "assets/img/foto2.jpg";
  altImg: string = "Viaggi avventura";

  percorsoLink: string = "http://www.lastampa.it";

  contenutoParagrafo: string = "nuovo contenuto";

  peso: number = 32;

  bloccato: boolean = true;

  stileTesto: string = "font-weight:bold;color:purple;font-size:1.4em;";

  classeTesto: string = "evidenziato";

  constructor() { }

  ngOnInit(): void {
  }

}
