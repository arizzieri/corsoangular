import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disposizione',
  templateUrl: './disposizione.component.html',
  styleUrls: ['./disposizione.component.css']
})
export class DisposizioneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
