import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colonne',
  templateUrl: './colonne.component.html',
  styleUrls: ['./colonne.component.css']
})
export class ColonneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
