import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spaziature',
  templateUrl: './spaziature.component.html',
  styleUrls: ['./spaziature.component.css']
})
export class SpaziatureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
