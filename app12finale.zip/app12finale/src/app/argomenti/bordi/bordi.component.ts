import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bordi',
  templateUrl: './bordi.component.html',
  styleUrls: ['./bordi.component.css']
})
export class BordiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
