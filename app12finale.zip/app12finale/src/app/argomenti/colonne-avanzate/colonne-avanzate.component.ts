import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colonne-avanzate',
  templateUrl: './colonne-avanzate.component.html',
  styleUrls: ['./colonne-avanzate.component.css']
})
export class ColonneAvanzateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
