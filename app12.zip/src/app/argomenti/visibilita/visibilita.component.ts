import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visibilita',
  templateUrl: './visibilita.component.html',
  styleUrls: ['./visibilita.component.css']
})
export class VisibilitaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
