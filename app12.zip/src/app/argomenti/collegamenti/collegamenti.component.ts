import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collegamenti',
  templateUrl: './collegamenti.component.html',
  styleUrls: ['./collegamenti.component.css']
})
export class CollegamentiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
