import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allineamento',
  templateUrl: './allineamento.component.html',
  styleUrls: ['./allineamento.component.css']
})
export class AllineamentoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
