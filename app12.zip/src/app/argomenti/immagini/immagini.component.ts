import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-immagini',
  templateUrl: './immagini.component.html',
  styleUrls: ['./immagini.component.css']
})
export class ImmaginiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
