import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-forms',
  templateUrl: './bootstrap-forms.component.html',
  styleUrls: ['./bootstrap-forms.component.css']
})
export class BootstrapFormsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
