export interface DatiUtente {
    "nome": string,
    "cognome": string,
    "intviaggi": boolean,
    "intmusica": boolean,
    "intcibo": boolean,
    "laurea": string,
    "esperienza": string,
    "commenti": string
}