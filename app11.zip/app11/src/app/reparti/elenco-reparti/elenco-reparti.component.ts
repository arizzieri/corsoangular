import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elenco-reparti',
  templateUrl: './elenco-reparti.component.html',
  styleUrls: ['./elenco-reparti.component.css']
})
export class ElencoRepartiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
