import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardiologia',
  templateUrl: './cardiologia.component.html',
  styleUrls: ['./cardiologia.component.css']
})
export class CardiologiaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
