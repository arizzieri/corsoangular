import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ortopedia',
  templateUrl: './ortopedia.component.html',
  styleUrls: ['./ortopedia.component.css']
})
export class OrtopediaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
