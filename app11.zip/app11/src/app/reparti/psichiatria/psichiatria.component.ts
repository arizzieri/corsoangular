import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-psichiatria',
  templateUrl: './psichiatria.component.html',
  styleUrls: ['./psichiatria.component.css']
})
export class PsichiatriaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
