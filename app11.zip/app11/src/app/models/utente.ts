export interface Utente {
    username: string,
    password: string,
    autenticato: boolean
}
