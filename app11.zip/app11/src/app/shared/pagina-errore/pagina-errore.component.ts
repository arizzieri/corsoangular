import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-errore',
  templateUrl: './pagina-errore.component.html',
  styleUrls: ['./pagina-errore.component.css']
})
export class PaginaErroreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
