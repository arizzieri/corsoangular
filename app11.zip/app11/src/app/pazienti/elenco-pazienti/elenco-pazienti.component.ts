import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elenco-pazienti',
  templateUrl: './elenco-pazienti.component.html',
  styleUrls: ['./elenco-pazienti.component.css']
})
export class ElencoPazientiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
