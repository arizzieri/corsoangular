export class Recensione {
    constructor(
        public codice: number,
        public autore: string,
        public testo: string,
        public punteggio: number
    ) { }
}
