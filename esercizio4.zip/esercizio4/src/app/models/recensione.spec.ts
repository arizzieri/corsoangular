import { Recensione } from './recensione';

describe('Recensione', () => {
  it('should create an instance', () => {
    expect(new Recensione()).toBeTruthy();
  });
});
