import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Recensione } from '../models/recensione';

@Component({
  selector: 'app-recensione',
  templateUrl: './recensione.component.html',
  styleUrls: ['./recensione.component.css']
})
export class RecensioneComponent implements OnInit {
  @Input() recensione: Recensione;
  @Output() modifica: EventEmitter<Recensione>;

  constructor() {
    this.recensione = new Recensione(0, "autore", "testo", 0);
    this.modifica = new EventEmitter<Recensione>();
  }

  ngOnInit(): void {
  }
  avvisaModifica(): void {
    // emette un evento verso il padre,
    // passando la recensione cliccata
    this.modifica.emit(this.recensione);
  }
}
