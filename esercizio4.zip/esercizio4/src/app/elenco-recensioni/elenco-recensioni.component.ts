import { Component, OnInit } from '@angular/core';
import { Recensione } from '../models/recensione';

@Component({
  selector: 'app-elenco-recensioni',
  templateUrl: './elenco-recensioni.component.html',
  styleUrls: ['./elenco-recensioni.component.css']
})
export class ElencoRecensioniComponent implements OnInit {
  recensioni: Recensione[];
  inserimento: boolean;
  modifiche: boolean;
  recensioneAttiva?: Recensione;

  constructor() {
    this.recensioni = [
      new Recensione(1, "andrea123", "prodotto molto valido", 3),
      new Recensione(2, "pippo456", "prodotto di bassa qualità", 1),
    ];
    this.inserimento = false;
    this.modifiche = false;
  }

  ngOnInit(): void {
  }

  attivaInserimento(): void {
    this.inserimento = !this.inserimento;
  }
  attivaModifiche(): void {
    this.modifiche = !this.modifiche;
  }

  inserisci(codice: any, autore: any, testo: any, punteggio: any): void {
    let nuovaRecensione = new Recensione(codice.value, autore.value, testo.value, punteggio.value);
    this.recensioni.push(nuovaRecensione);
    codice.value = 0;
    autore.value = '';
    testo.value = '';
    punteggio.value = 0;
    this.inserimento = false;
  }
  modifica(recensione: Recensione): void {
    this.recensioneAttiva = recensione;
  }
  conferma(codice: any, autore: any, testo: any, punteggio: any): void {
    // modifico recensione
    this.recensioneAttiva!.codice = codice.value;
    this.recensioneAttiva!.autore = autore.value;
    this.recensioneAttiva!.testo = testo.value;
    this.recensioneAttiva!.punteggio = punteggio.value;

    // svuoto campi
    codice.value = 0;
    autore.value = '';
    testo.value = '';
    punteggio.value = 0;
    // tolgo recensione attiva
    this.recensioneAttiva = undefined;
  }

  annulla(): void {
    // chiudere il box di modifica
    this.recensioneAttiva = undefined;
  }
}
