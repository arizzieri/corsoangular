import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scelta',
  templateUrl: './scelta.component.html',
  styleUrls: ['./scelta.component.css']
})
export class SceltaComponent implements OnInit {

  visibile: boolean = true;
  nascosto: boolean = false;

  numero: number = 6;

  mostraComponente: boolean = true;

  persona: any = {
    nome: "Domenica",
    cognome: "Rossi",
    anni: 44
  };

  colore: string = "giallo";

  constructor() { }

  ngOnInit(): void {
  }

}
