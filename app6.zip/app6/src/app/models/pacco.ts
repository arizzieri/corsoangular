export interface Pacco {
    codice: number;
    contenuto: string;
    peso: number;
    pesoImballo?: number; // opzionale
}
