import { Component, OnInit } from '@angular/core';
import { Persona } from '../models/persona';

@Component({
  selector: 'app-test-classi',
  templateUrl: './test-classi.component.html',
  styleUrls: ['./test-classi.component.css']
})
export class TestClassiComponent implements OnInit {
  // istanza di una persona presa dal model 
  persona: Persona;

  // array di oggetti di tipo persona
  elencoPersone: Persona[];

  // altro array di persone
  listaPersone: Persona[];

  constructor() {
    // inizializzo persona
    this.persona = new Persona("Maria", "Bianchi", 34);

    // inizializzo array di persone
    this.elencoPersone = [
      new Persona("Maria", "Bianchi", 34),
      new Persona("Silvia", "Rossi", 56),
      new Persona("Valeria", "Verdi", 78)
    ];

    // inizializzo altro array
    this.listaPersone = [
      {
        nome: "Maria",
        cognome: "Bianchi",
        anni: 34
      },
      {
        nome: "Maria",
        cognome: "Rossi",
        anni: 56
      },
      {
        nome: "Maria",
        cognome: "Verdi",
        anni: 78
      }
    ];
  }

  ngOnInit(): void {
    /*
    // creo istanza di scatola
    const s1 = new Scatola("pietre", 18);
    const s2 = new Scatola("monete");

    // leggo contenuto scatole
    console.log("contenuto di s1: " + s1.contenuto + ", peso: " + s1.peso);
    console.log("contenuto di s2: " + s2.contenuto + ", peso: " + s2.peso);

    s1.contenuto = "foglie";
    s2.peso = 6;

    // ristampo i dati
    console.log("contenuto di s1: " + s1.contenuto + ", peso: " + s1.peso);
    console.log("contenuto di s2: " + s2.contenuto + ", peso: " + s2.peso);

    // chiamo metodo stampaDati()
    s1.stampaDati();
    s2.stampaDati();
    */
  }

}

// definisco una nuova classe
class Scatola {
  // attributi
  private _contenuto: string;
  private _peso: number;

  // costruttore
  constructor(c: string, p?: number) {
    this._contenuto = c;
    this._peso = p || 0;
  }

  // metodi 
  // metodi getter 
  get contenuto(): string {
    return this._contenuto;
  }
  get peso(): number {
    return this._peso;
  }
  // metodi setter
  set contenuto(c: string) {
    this._contenuto = c;
  }
  set peso(p: number) {
    if (p >= 0) {
      this._peso = p;
    } else {
      console.log("errore: non puoi assegnare un peso negativo!");
    }
  }

  // altri tipi di metodi
  stampaDati(): void {
    console.log("Contenuto scatola: " + this.contenuto + ", peso: " + this.peso);
  }




}