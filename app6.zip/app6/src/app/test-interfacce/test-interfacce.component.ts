import { Component, OnInit } from '@angular/core';
import { Pacco } from '../models/pacco';

@Component({
  selector: 'app-test-interfacce',
  templateUrl: './test-interfacce.component.html',
  styleUrls: ['./test-interfacce.component.css']
})
export class TestInterfacceComponent implements OnInit {
  // dichiaro un pacco
  mioPacco: Pacco;

  // dichiaro un array di pacchi
  pacchi: Pacco[];

  // dichiaro una variabile per contenere il pacco che seleziono dalla lista
  paccoSelezionato?: Pacco;

  constructor() {
    this.mioPacco = { // inizializzo pacco singolo
      codice: 4,
      contenuto: "lettere",
      peso: 2,
      pesoImballo: 0.5
    };

    this.pacchi = [ // inizializzo array di pacchi
      {
        codice: 1,
        contenuto: "maglie",
        peso: 12
      },
      {
        codice: 2,
        contenuto: "scarpe",
        peso: 16,
        pesoImballo: 1.2
      },
      {
        codice: 3,
        contenuto: "pantaloni",
        peso: 25,
        pesoImballo: 2.5
      },
      {
        codice: 4,
        contenuto: "giacche",
        peso: 30
      }
    ];
  }

  ngOnInit(): void {
    /*
    let m1 = new Manager(2, "Francesco", "Gialli", "qualità");
    m1.stampaDati();
    */
  }

  seleziona(p: Pacco): void {
    // qui assegno il pacco selezionato con il pacco cliccato
    this.paccoSelezionato = p;
  }

  togliSelezione(): void {
    // qui svuoto il pacco selezionato 
    this.paccoSelezionato = undefined;
  }
}
/*
interface Dipendente {
  matricola: number,
  cognome: string,
  nome: string,
  stampaDati(): void
}

class Manager implements Dipendente {
  matricola: number;
  cognome: string;
  nome: string;
  reparto: string;

  constructor(m: number, c: string, n: string, r: string) {
    this.matricola = m;
    this.cognome = c;
    this.nome = n;
    this.reparto = r;
  }

  stampaDati(): void {
    console.log("sono il dipendente con matricola " + this.matricola + " e sono un manager del reparto " + this.reparto);
  }

}
*/