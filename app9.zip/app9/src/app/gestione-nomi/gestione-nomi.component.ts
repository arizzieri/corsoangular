import { Component, OnInit } from '@angular/core';
import { NomeService } from './nome.service';

@Component({
  selector: 'app-gestione-nomi',
  templateUrl: './gestione-nomi.component.html',
  styleUrls: ['./gestione-nomi.component.css']
})
export class GestioneNomiComponent implements OnInit {
  nomi: string[];

  // inietto i servizio nel costruttore
  constructor(private ns: NomeService) {
    this.nomi = [];
  }
  ngOnInit(): void {
    this.nomi = this.ns.getNomi();
  }

  inserisci(nome: any): void {
    // chiedere al servizio di aggiungere il valore della casella nome
    this.ns.addNome(nome.value);

    // pulire la casella del nome
    nome.value = '';
  }

}
