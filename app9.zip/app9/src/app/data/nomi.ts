export const nomi: string[] = [
    "Serena", "Gabriele", "Franco", "Silvia"
];