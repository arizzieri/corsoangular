import { Studente } from "../models/studente";

export const studenti: Studente[] = [
    {
        matricola: 1,
        cognome: "Rana",
        nome: "Giovanni",
        media: 60
    },
    {
        matricola: 2,
        cognome: "Gallo",
        nome: "Simona",
        media: 90
    },
    {
        matricola: 3,
        cognome: "Cane",
        nome: "Marco",
        media: 75
    },
    {
        matricola: 4,
        cognome: "Gatto",
        nome: "Silvana",
        media: 88
    },
];