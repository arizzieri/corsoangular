export interface Studente {
    matricola: number,
    cognome: string,
    nome: string,
    media: number
}
