import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-html5-forms',
  templateUrl: './html5-forms.component.html',
  styleUrls: ['./html5-forms.component.css']
})
export class Html5FormsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
