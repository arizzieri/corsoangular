import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nuovo',
  templateUrl: './nuovo.component.html',
  styleUrls: ['./nuovo.component.css']
})
export class NuovoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
