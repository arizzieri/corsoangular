import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EtichettaComponent } from './etichetta.component';

describe('EtichettaComponent', () => {
  let component: EtichettaComponent;
  let fixture: ComponentFixture<EtichettaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EtichettaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EtichettaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
