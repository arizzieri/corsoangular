import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-etichetta',
  templateUrl: './etichetta.component.html',
  styleUrls: ['./etichetta.component.css']
})
export class EtichettaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
