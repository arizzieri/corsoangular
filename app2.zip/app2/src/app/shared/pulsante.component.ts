import { Component } from "@angular/core";

@Component({
    selector: 'pulsante',
    template: '<button>{{label}}</button>'
})
export class PulsanteComponent {
    //attributi
    label: string = 'invia';
}